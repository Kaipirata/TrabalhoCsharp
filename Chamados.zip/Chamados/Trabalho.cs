using System;
using System.IO;
using System.Collections.Generic;
using System.Security.Cryptography;

namespace Trabalho
{

    class Funcionario
    {
        public long idFuncionario;
        public string nomeFuncionario;
        public string especializacaoFuncionario;

        public Funcionario(long IdFunc, string NomFunc, string EspecFunc)
        {
            this.idFuncionario = IdFunc;
            this.nomeFuncionario = NomFunc;
            this.especializacaoFuncionario = EspecFunc;
        }

        public long GetIdFuncionario()
        {
            return idFuncionario;
        }

        public string GetNomeFuncionario()
        {
            return nomeFuncionario;
        }

        public string GetEspecializacao()
        {
            return especializacaoFuncionario;
        }

        public void SetIdFuncionario(long IdFunc)
        {
            idFuncionario = IdFunc;
        }

        public void SetNomeFuncionario(string NomFunc)
        {
            nomeFuncionario = NomFunc;
        }

        public void SetEspecializacaoFuncionario(string especFunc)
        {
            especializacaoFuncionario = especFunc;
        }

        public string SerializarFuncionario()
        {
            return idFuncionario + "," + nomeFuncionario + "," + especializacaoFuncionario;
        }
    }

    class Cliente
    {
        public long idCliente;
        public string nomeCliente;
        public string empresaCliente;

        public Cliente(long IdCli, string NomeCli, string EmpresaCli)
        {
            this.idCliente = IdCli;
            this.nomeCliente = NomeCli;
            this.empresaCliente = EmpresaCli;
        }

        public long GetIdCliente()
        {
            return idCliente;
        }

        public string GetNomeCliente()
        {
            return nomeCliente;
        }

        public string GetEmpresaCliente()
        {
            return empresaCliente;
        }

        public void SetIdCliente(long IdCli)
        {
            idCliente = IdCli;
        }

        public void SetNomeCliente(string NomeCli)
        {
            nomeCliente = NomeCli;
        }

        public void SetEmpresaCliente(string EmpresaCli)
        {
            empresaCliente = EmpresaCli;
        }

        public string SerializarCliente()
        {
            return idCliente + "," + nomeCliente + "," + empresaCliente;
        }

    }

    class Chamado
    {
        public long idChamado;
        public string descricaoChamado;
        public string naturezaAtendimento;
        public long idClienteChamado;
        public long idFuncionarioChamado;

        public Chamado(long IdChamado, string DescricaoChamado, string NaturezaAtendimento, long Cliente, long Funcionario)
        {
            this.idChamado = IdChamado;
            this.descricaoChamado = DescricaoChamado;
            this.naturezaAtendimento = NaturezaAtendimento;
            this.idClienteChamado = Cliente;
            this.idFuncionarioChamado = Funcionario;
        }

        public long GetIdChamado()
        {
            return idChamado;
        }

        public string GetDescicaoChamado()
        {
            return descricaoChamado;
        }

        public string GetNaturezaAtendimento()
        {
            return naturezaAtendimento;
        }

        public long GetClienteChamado()
        {
            return idClienteChamado;
        }

        public long GetFuncionarioChamado()
        {
            return idFuncionarioChamado;
        }

        public void SetIdChamado(long IdChamado)
        {
            idChamado = IdChamado;
        }

        public void SetDescricaoChamado(string DescricaoChamado)
        {
            descricaoChamado = DescricaoChamado;
        }

        public void SetNaturezaAtendimento(string NatAtendCli)
        {
            naturezaAtendimento = NatAtendCli;
        }

        public void SetClienteChamado(long ClienteChamado)
        {
            idClienteChamado = ClienteChamado;
        }

        public void SetFuncionarioChamado(long FuncionarioChamado)
        {
            idFuncionarioChamado = FuncionarioChamado;
        }

        public string SerializarChamado()
        {
            return idChamado + "," + descricaoChamado + "," + naturezaAtendimento + "," + idClienteChamado + "," + idFuncionarioChamado;
        }
    }

    class BaseFuncionarios
    {
        string filename;
        List<Funcionario> funcionarios;

        public BaseFuncionarios(string f = "funcionarios.txt")
        {
            filename = f;
            funcionarios = new List<Funcionario>();
            CarregarFuncionario();
        }

        public void CarregarFuncionario()
        {
            if (!File.Exists(filename))
            {
                File.CreateText(filename);
            }
            string input = File.ReadAllText(filename);
            string[] linhas = input.Split("\n");
            foreach (var linha in linhas)
            {
                if (linha.Length > 0)
                {
                    string[] valores = linha.Split(",");
                    Funcionario funcionario = new Funcionario(long.Parse(valores[0]), valores[1], valores[2]);
                    funcionarios.Add(funcionario);
                }
            }
        }

        public string SerializarFuncionario()
        {
            string output = "";
            foreach (var funcionario in funcionarios)
            {
                output += funcionario.SerializarFuncionario() + "\n";
            }
            return output;
        }

        public void SalvarFuncionario()
        {
            string output = SerializarFuncionario();
            File.WriteAllText(filename, output);
        }

        public void LimparFuncionario()
        {
            funcionarios.Clear();
        }

        public void AdicionarFuncionario(Funcionario f)
        {
            foreach (var funcionario in funcionarios)
            {
                //lanca erro caso funcionario ja esteja na lista ou nome ja esteja em uso
                if (funcionario.GetIdFuncionario() == f.GetIdFuncionario())
                {
                    throw new Exception($"Id do Funcionario '{f.GetIdFuncionario()}' ja esta na lista");
                }
                else if (funcionario.GetNomeFuncionario() == f.GetNomeFuncionario())
                {
                    throw new Exception($"Nome de funcionario '{f.GetNomeFuncionario()}' ja esta sendo utilizado");
                }
            }
            funcionarios.Add(f);
            SalvarFuncionario();
        }

        public void AtualizarFuncionario(Funcionario f)
        {
            foreach (var funcionario in funcionarios)
            {
                if (funcionario.GetIdFuncionario() == f.GetIdFuncionario())
                {
                    funcionarios.Remove(funcionario);
                    funcionarios.Add(f);
                    return;
                }
            }
            //caso nao encontre o funcionario, lanca erro
            throw new Exception($"funcionario '{f.GetNomeFuncionario()}' nao foi encontrado na base");
        }

        public void RemoverFuncionario(Funcionario f)
        {
            foreach (var funcionario in funcionarios)
            {
                if (funcionario.GetIdFuncionario() == f.GetIdFuncionario())
                {
                    funcionarios.Remove(funcionario);
                    return;
                }
            }
        }

        //retorna funcionario que possui nome indicado
        public Funcionario BuscarPorNome(string nomeFuncionario)
        {
            foreach (var funcionario in funcionarios)
            {
                if (funcionario.GetNomeFuncionario() == nomeFuncionario)
                {
                    return funcionario;
                }
            }
            //caso nao encontre, lanca erro
            throw new Exception($"funcionario '{nomeFuncionario}' nao foi encontrado na base");
        }

        public Funcionario BuscarPorId(long idFuncionario)
        {
            foreach (var funcionario in funcionarios)
            {
                if (funcionario.GetIdFuncionario() == idFuncionario)
                {
                    return funcionario;
                }
            }
            //caso nao encontre, lanca erro
            throw new Exception($"id funcionario '{idFuncionario}' nao foi encontrado na base");
        }

    }


    class BaseClientes
    {
        string filename;
        List<Cliente> clientes;

        public BaseClientes(string c = "clientes.txt")
        {
            filename = c;
            clientes = new List<Cliente>();
            Carregar();
        }

        public void Carregar()
        {
            if (!File.Exists(filename))
            {
                File.CreateText(filename);
            }
            string input = File.ReadAllText(filename);
            string[] linhas = input.Split("\n");
            foreach (var linha in linhas)
            {
                if (linha.Length > 0)
                {
                    string[] valores = linha.Split(",");
                    Cliente cliente = new Cliente(long.Parse(valores[0]), valores[1], valores[2]);
                    clientes.Add(cliente);
                }
            }
        }

        public string SerializarCliente()
        {
            string output = "";
            foreach (var cliente in clientes)
            {
                output += cliente.SerializarCliente() + "\n";
            }
            return output;
        }

        public void SalvarCliente()
        {
            string output = SerializarCliente();
            File.WriteAllText(filename, output);
        }

        public void LimparCliente()
        {
            clientes.Clear();
        }

        public void AdicionarCliente(Cliente c)
        {
            foreach (var cliente in clientes)
            {
                //lanca erro caso id cliente ja esteja na lista ou nome ja esteja em uso
                if (cliente.GetIdCliente() == c.GetIdCliente())
                {
                    throw new Exception($"cliente '{c.GetIdCliente()}' ja esta na lista");
                }
                else if (cliente.GetNomeCliente() == c.GetNomeCliente())
                {
                    throw new Exception($"Nome '{c.GetNomeCliente()}' ja esta sendo utilizado");
                }
            }
            clientes.Add(c);
            SalvarCliente();
        }

        public void AtualizarCliente(Cliente c)
        {
            foreach (var cliente in clientes)
            {
                if (cliente.GetIdCliente() == c.GetIdCliente())
                {
                    clientes.Remove(cliente);
                    clientes.Add(c);
                    return;
                }
            }
            //caso nao encontre o cliente, lanca erro
            throw new Exception($"cliente '{c.GetNomeCliente()}' nao foi encontrado na base");
        }

        public void RemoverCliente(Cliente c)
        {
            foreach (var cliente in clientes)
            {
                if (cliente.GetIdCliente() == c.GetIdCliente())
                {
                    clientes.Remove(cliente);
                    return;
                }
            }
        }

        //retorna cliente que possui nome indicado
        public Cliente BuscarPorNome(string nomeCliente)
        {
            foreach (var cliente in clientes)
            {
                if (cliente.GetNomeCliente() == nomeCliente)
                {
                    return cliente;
                }
            }
            //caso nao encontre, lanca erro
            throw new Exception($"cliente '{nomeCliente}' nao foi encontrado na base");
        }

        public Cliente BuscarPorId(long idCliente)
        {
            foreach (var cliente in clientes)
            {
                if (cliente.GetIdCliente() == idCliente)
                {
                    return cliente;
                }
            }
            //caso nao encontre, lanca erro
            throw new Exception($"cliente id '{idCliente}' nao foi encontrado na base");
        }

    }


    class BaseChamados
    {
        string filename;
        List<Chamado> chamados;

        public BaseChamados(string c = "chamados.txt")
        {
            filename = c;
            chamados = new List<Chamado>();
            CarregarChamado();
        }

        public void CarregarChamado()
        {
            if (!File.Exists(filename))
            {
                File.CreateText(filename);
            }
            string input = File.ReadAllText(filename);
            string[] linhas = input.Split("\n");
            foreach (var linha in linhas)
            {
                if (linha.Length > 0)
                {
                    string[] valores = linha.Split(",");
                    Chamado chamado = new Chamado(long.Parse(valores[0]), valores[1], valores[2], long.Parse(valores[3]), long.Parse(valores[4]));
                    chamados.Add(chamado);
                }
            }
        }

        public string SerializarChamado()
        {
            string output = "";
            foreach (var chamado in chamados)
            {
                output += chamado.SerializarChamado() + "\n";
            }
            return output;
        }

        public void SalvarChamado()
        {
            string output = SerializarChamado();
            File.WriteAllText(filename, output);
        }

        public void LimparChamado()
        {
            chamados.Clear();
        }

        public void AdicionarChamado(Chamado c)
        {
            foreach (var chamado in chamados)
            {
                //lança erro caso id chamado ja esteja na lista 
                if (chamado.GetIdChamado() == c.GetIdChamado())
                {
                    throw new Exception($"chamado '{c.GetIdChamado()}' ja esta na lista");
                }
            }
            chamados.Add(c);
            SalvarChamado();
        }

        public void AtualizarChamado(Chamado c)
        {
            foreach (var chamado in chamados)
            {
                if (chamado.GetIdChamado() == c.GetIdChamado())
                {
                    chamados.Remove(chamado);
                    chamados.Add(c);
                    return;
                }
            }
            //caso nao encontre o chamdo, lanca erro
            throw new Exception($"chamado '{c.GetIdChamado()}' nao foi encontrado na base");
        }

        public void RemoverChamado(Chamado c)
        {
            foreach (var chamado in chamados)
            {
                if (chamado.GetIdChamado() == c.GetIdChamado())
                {
                    chamados.Remove(chamado);
                    return;
                }
            }
        }

        public Chamado BuscarPorId(long idChamado)
        {
            foreach (var chamado in chamados)
            {
                if (chamado.GetIdChamado() == idChamado)
                {
                    return chamado;
                }
            }
            //caso nao encontre, lanca erro
            throw new Exception($"id '{idChamado}' nao foi encontrado na base");
        }

        public Chamado BuscarPorNatureza(string naturezaChamado)
        {
            foreach (var chamado in chamados)
            {
                if (chamado.GetNaturezaAtendimento() == naturezaChamado)
                {
                    return chamado;
                }
            }
            //caso nao encontre, lanca erro
            throw new Exception($"Natureza '{naturezaChamado}' nao foi encontrada na base");
        }

    }

}