using System;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;

//essa eh uma "minimal webapi" (requer SDK .NET 6.0 ou superior)
//criar projeto com o comando "dotnet new webapi -minimal -o NomeDoProjeto"
//para testar esse codigo, substitua o Program.cs do projeto criado por esse
//executar o projeto com o comando "dotnet run" ou "dotnet watch run" (esse atualiza o servico em tempo real se o codigo for alterado)
//verificar nas informacoes impressas em quais enderecos a API esta recebendo os chamados

namespace Trabalho
{
    class Program
    {
        //exemplo de funcoes estatica que pode ser mapeadas em algum endpoint da api
        static string welcome()
        {
            return "Chamados esta rodando \n Kaique Fernandes \n Allan Thony \n Willian Nalon";
        }

        static void Main(string[] args)
        {
            //cria o criador (builder) de aplicacoes
            var builder = WebApplication.CreateBuilder(args);

            //cria a aplicacao usando o builder
            var app = builder.Build();

            //instancia nossas bases de clientes, funcionarios e chamados

            BaseClientes baseClientes = new BaseClientes("clientes.txt");
            BaseFuncionarios baseFuncionarios = new BaseFuncionarios("funcionarios.txt");
            BaseChamados baseChamados = new BaseChamados("chamados.txt");

            //mapeia a raiz da nossa url para a funcao "welcome" via metodo GET (observe que a propria funcao esta sendo enviada como argumento, e nao o retorno dela)
            app.MapGet("/", welcome);



            //Funcionario
            var GetFuncionarios = () =>
            {
                return baseFuncionarios.SerializarFuncionario();
            };

            //Clientes
            var GetClientes = () =>
            {
                return baseClientes.SerializarCliente();
            };

            //Chamados
            var GetChamados = () =>
            {
                return baseChamados.SerializarChamado();
            };



            //mapeia a funcao acima para para o path "funcionarios" via metodo GET
            app.MapGet("/funcionarios", GetFuncionarios);

            //mapeia a funcao acima para para o path "clientes" via metodo GET
            app.MapGet("/clientes", GetClientes);

            //mapeia a funcao acima para para o path "chamados" via metodo GET
            app.MapGet("/chamados", GetChamados);


            //cria uma funcao lambda que retorna uma impressao de um funcionario
            var getFuncionario = (string nomeFuncionario) =>
            {
                return baseFuncionarios.BuscarPorNome(nomeFuncionario).SerializarFuncionario();
            };

            //cria uma funcao lambda que retorna uma impressao de um cliente
            var getCliente = (string nomeCliente) =>
            {
                return baseClientes.BuscarPorNome(nomeCliente).SerializarCliente();
            };

            //cria uma funcao lambda que retorna uma impressao de um chamado
            var getChamado = (long idChamado) =>
            {
                return baseChamados.BuscarPorId(idChamado).SerializarChamado();
            };



            //mapeia a funcao acima para o path "funcionario/{nomeFuncionario}", onde {nomeFuncionario} eh o valor que sera enviado para o argumento "nomeFuncionario" da funcao "getFuncionario"
            app.MapGet("/funcionario/{nomeFuncionario}", getFuncionario);

            //mapeia a funcao acima para o path "cliente/{nomeCliente}", onde {nomeCliente} eh o valor que sera enviado para o argumento "nomeCliente" da funcao "getCliente"
            app.MapGet("/cliente/{nomeCliente}", getCliente);

            //mapeia a funcao acima para o path "chamado/{idChamado}", onde {idChamado} eh o valor que sera enviado para o argumento "idChamado" da funcao "getChamado"
            app.MapGet("/chamado/{idChamado}", getChamado);


            //cria uma funcao lambda que recebe um record (declarado no final desse codigo), usa esse record para criar um funcionario e insere esse funcionario na base
            var postFuncionario = (ChavesFuncionario f) =>
            {
                var funcionario = new Funcionario(f.idFuncionario, f.nomeFuncionario, f.especializacaoFuncionario);
                baseFuncionarios.AdicionarFuncionario(funcionario);
                return "Funcionario adicionado";
            };

            //cria uma funcao lambda que recebe um record (declarado no final desse codigo), usa esse record para criar um cliente e insere esse cliente na base
            var postCliente = (ChavesCliente c) =>
            {
                var cliente = new Cliente(c.idCliente, c.nomeCliente, c.empresaCliente);
                baseClientes.AdicionarCliente(cliente);
                return "Cliente adicionado";
            };

            //cria uma funcao lambda que recebe um record (declarado no final desse codigo), usa esse record para criar um chamado e insere esse chamado na base
            var postChamado = (ChavesChamado c) =>
            {
                var chamado = new Chamado(c.idChamado, c.descricaoChamado, c.naturezaAtendimento, c.idClienteChamado, c.idFuncionarioChamado);
                baseChamados.AdicionarChamado(chamado);
                return "Chamado adicionado";
            };


            //mapeia a funcao acima para o path "cadastrar" usando o metodo POST (o paylod do POST deve ser um JSON que sera mapeado para o record)
            app.MapPost("/cadastrarFuncionario", postFuncionario);
            app.MapPost("/cadastrarCliente", postCliente);
            app.MapPost("/cadastrarChamado", postChamado);




            //atualizar funcionario
            app.MapPost("/atualizarFuncionario/{id}", (BaseFuncionarios baseFuncionarios, Funcionario funcionarioAtualizado, int idFuncionario) =>
            {
                var funcionario = baseFuncionarios.BuscarPorId(idFuncionario);
                funcionario.nomeFuncionario = funcionarioAtualizado.nomeFuncionario;
                funcionario.especializacaoFuncionario = funcionarioAtualizado.especializacaoFuncionario;
                
                baseFuncionarios.AtualizarFuncionario(funcionario);
                return "funcionario atualizado";
            });

            //atualizar cliente
            app.MapPost("/atualizarCliente/{id}", (BaseClientes baseClients, Cliente clienteAtualizado, int idCliente) =>
            {
                var cliente = baseClientes.BuscarPorId(idCliente);
                cliente.nomeCliente = clienteAtualizado.nomeCliente;
                cliente.empresaCliente = clienteAtualizado.empresaCliente;
                baseClientes.AtualizarCliente(cliente);
                return "cliente atualizado";
            });

            //atualizar chamado
            app.MapPost("/atualizarChamado/{id}", (BaseChamados baseChamados, Chamado chamadoAtualizado, int idChamado) =>
            {
                var chamado = baseChamados.BuscarPorId(idChamado);
                chamado.descricaoChamado = chamadoAtualizado.descricaoChamado;
                chamado.naturezaAtendimento = chamadoAtualizado.naturezaAtendimento;
                chamado.idClienteChamado = chamadoAtualizado.idClienteChamado;
                chamado.idFuncionarioChamado = chamadoAtualizado.idFuncionarioChamado;
                baseChamados.AtualizarChamado(chamado);
                return "chamado atualizado";
            });





            //deletar funcionario
            app.MapPost("/deletarFuncionario/{id}", (BaseFuncionarios baseFuncionarios, int idFuncionario) =>
            {
                // try
                // {
                    var funcionario = baseFuncionarios.BuscarPorId(idFuncionario);
                    baseFuncionarios.RemoverFuncionario(funcionario);
					return "funcionario removido";
                // }
                // catch (Exception erro)
                // {
                //     return "Nao foi possivel remover o funcionario " + idFuncionario;
                // }                
            });

            //deletar cliente
            app.MapPost("/deletarClinte/{id}", (BaseClientes baseClientes, int idCliente) =>
            {
                    var cliente = baseClientes.BuscarPorId(idCliente);
                    baseClientes.RemoverCliente(cliente);
					return "cliente removido";
            });

            //deletar chamado
            app.MapPost("/deletarChamado/{id}", (BaseChamados baseChamados, int idChamado) =>
            {
                    var chamado = baseChamados.BuscarPorId(idChamado);
                    baseChamados.RemoverChamado(chamado);
					return "funcionario removido";
            });


            //inicia a aplicacao
            app.Run();
        }

        //esse record possui o nome das chaves do JSON que o POST deve enviar e que a funcao chamada pelo POST quer receber
        record ChavesFuncionario(long idFuncionario, string nomeFuncionario, string especializacaoFuncionario);
        record ChavesCliente(long idCliente, string nomeCliente, string empresaCliente);
        record ChavesChamado(long idChamado, string descricaoChamado, string naturezaAtendimento, long idClienteChamado, long idFuncionarioChamado);

    }
}